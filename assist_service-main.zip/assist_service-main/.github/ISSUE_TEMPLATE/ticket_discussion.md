---
name: Ticket discussion
about: Place to go through and agree on implementation of a ticket on the dev side
title: ''
labels: ''

---

## Issue ticket link

## Related Pull Requests

## Summary
